require("dotenv").config();
const cors = require("cors");
const express = require("express");
const serverless = require('serverless-http');

const router = require("./src/app.router.js");
const mongoConnect = require("./src/app.db.js");

const app = express();

// Disable x-powered-by header to prevent version disclosure
app.disable("x-powered-by");

// command to parse the incoming request
app.use(express.json());

// connect to the database
mongoConnect();

// Middleware to handle errors
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});


// setting up cors
const allowedOrigins = [
    "https://securevault.pages.dev",
    "https://dev.securevault.pages.dev",
    "https://test.securevault.pages.dev",
]
const corsOptions = {
    origin: allowedOrigins,
    credentials: true,
};
app.use(cors(corsOptions))


// setting up router
app.use("/api", router);
app.get("/", (req, res) => { res.send("Secure-Vault Server is up and running!!"); });
app.get('/hello', (req, res) => {
    res.json({ hello: 'world' });
});


app.listen(3000, () => {
    console.log(`Server started`);
});

module.exports.handler = serverless(app);
